<?php
/**
 * Template name: Homepage
 */

get_header();
?>
<?php
while ( have_posts() ) : the_post();
?>

<div class="block-form-contact">
	<section>
		<h1><?php echo get_post_meta($post->ID, 'ale_title', true); ?></h1>
		<h2>Производство и доставка бетона в Москве и Московской области</h2>
		<p>Оставьте заявку и мы предоставим вам<br><mark>САМУЮ НИЗКУЮ ЦЕНУ</mark> на бетон в Москве!</p>
		<div class="sheep">ОСТАЛОСЬ 2 ЗАЯВКИ СО СКИДКОЙ</div>
		<?php echo do_shortcode('[contact-form-7 id="44" title="Контактная форма 1"]'); ?>
	</section>
</div>
<section class="main-support">
	<h1>Получить консультацию от менеджера по телефону: <ins><?php echo get_theme_mod('contact_phone'); ?></ins></h1>
</section>
<section class="grid-item amenity">
	<div class="wrapper">
		<div>
			<div>
				<h3>Низкие цены</h3>
				<p>Лучшее предложение на рынке до неприличия, а также Москвы и Московской области, бетон от 2100 руб за куб!</p>
			</div>
			<div>
				<h3>Доставка в любую точку</h3>
				<p>Собственный парк миксеров и бетононасосов, доставляем бетон круглосуточно, точно в срок, всегда в нужном объеме.</p>
			</div>
			<div>
				<h3>Любой объем</h3>
				<p>Доставляем бетон от 1 куба! Для крупных заказчиков - наши мощности позволяют отгружать до 3000 кубов в сутки!</p>
			</div>
		</div>
	</div>
</section>
<div class="wrapper">
	<center><h1>СЕГОДНЯ <mark><?php echo date ('d.m.Y'); ?></mark> вы получаете <mark>10% скидку</mark> на продукцию</h1></center>
	<table class="price-list">
		<thead><tr><th>Наименование</th> <th>Стоимость</th> <th>Количество кубов</th></tr></thead>
		<tbody>
			<?php
			$marks = new WP_Query(array('post_type' => 'marks', 'posts_per_page' => -1, 'order'   => 'ASC')); 
			if ($marks->have_posts()) :
				while ($marks->have_posts()) :
					$marks->the_post();
			?>
					<tr><td><?php the_title(); ?></td> <td><?php echo get_the_excerpt(); ?></td> <td nowrap="nowrap"><div class="in-box"><div id="<?php echo get_the_ID(); ?>" class="minusPlus minus" value="<?php echo get_the_excerpt(); ?>">-</div><input type="number" name="num" value="0" min="0" readonly="readonly" class="inputNumber" id="amount<?php echo get_the_ID(); ?>"><div id="<?php echo get_the_ID(); ?>" class="minusPlus plus" value="<?php echo get_the_excerpt(); ?>">+</div></div></td></tr>
			<?php
			endwhile;
			endif;
			wp_reset_query();
			?>
		</tbody>
	</table>
	<button class="cost-calculation order-click">ПОЛУЧИТЬ РАСЧЕТ СТОИОМСТИ</button>
</div>
<section class="grid-item amenity">
	<div class="wrapper">
		<div>
			<div>
				<h1>Узнайте, как получить бетононасос и доставку бетона на объект БЕСПЛАТНО!</h1>
			</div>
			<div>
				<button class="order-click">ПОЛУЧИТЬ ДОСТАВКУ И БЕТОНОНАСОС</button>
			</div>
			<div class="flex-amenity">
				<img src="http://betonnyi-zavod.ru/template/img/betonanasos.png">
			</div>
		</div>
	</div>
</section>
<div class="wrapper">
	<main id="content" class="site-content">
		<div class="grid-item delivery">
			<h1>Доставка бетона в любую точку Москвы и московской области</h1>
			<p><?php the_content(); ?></p>
		</div>
		<div class="grid-item collaboration">
			<div class="grid-item">
				<?php echo get_post_meta($post->ID, 'ale_video', true); ?>
			</div>
			<div class="grid-item">
				<h1>5 главных причин начать сотрудничество с нами</h1>
				<ul>
					<li>Бесплатный выезд специалиста для точного расчета необходимого объема бетона</li>
					<li>Доставим бетон в любую точку Москвы и области по лучшей цене</li>
					<li>3 собственных аккредитованных лаборатории</li>
					<li>32 миксера и 14 бетононасосов в автопарке привезем бетон в течении 2 часов</li>
					<li>Строгое соблюдение ГОСТа , вся продукция подтверждается сертификатами и проходит лабораторный анализ.</li>
				</ul>
				<button class="order-click">ПОЛУЧИТЬ КОНСУЛЬТАЦИЮ</button>
			</div>
		</div>
		<div class="grid-item reviews">
			<h1>Отзывы о нашей компании</h1>
			<section>
				<div class="grid-item">
					<?php echo get_post_meta($post->ID, 'ale_review_first', true); ?>
				</div>
				<div class="grid-item">
					<?php echo get_post_meta($post->ID, 'ale_review_second', true); ?>
				</div>
				<div class="grid-item">
					<?php echo get_post_meta($post->ID, 'ale_review_third', true); ?>
				</div>
			</section>
		</div>
		<div class="grid-item license">
			<div class="grid-item testimonies">
				<img src="http://betonnyi-zavod.ru/template/img/svidetelstvo.svg">
				<p>Свидетельства и сертификаты качества</p>
			</div>
			<div class="grid-item supply">
				<img src="http://betonnyi-zavod.ru/template/img/dogovor.svg">
				<p>Договор поставки</p>
			</div>
			<div class="grid-item">
				<h1>Сеть бетонных заводов</h1>
				<h3>15 лет на рынке Москвы и МО</h3>
				<hr>
				<h2><?php echo get_theme_mod('contact_phone'); ?></h2>
				<button class="order-click">КОНСУЛЬТАЦИЯ С МЕНЕДЖЕРОМ</button>
			</div>
		</div>
	</main>
</div>

<?php endwhile; ?>

<?php get_footer();