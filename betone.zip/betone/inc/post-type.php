<?php
function coralina_custom_post_type_marks() {
    $labels = array(
        'name'                  => 'Марки',
        'singular_name'                  => 'Марка'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'marks' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
    );
    register_post_type( 'marks', $args );
}
add_action( 'init', 'coralina_custom_post_type_marks' );

function coralina_custom_post_type_services() {
    $labels = array(
        'name'                  => 'Услуги',
        'singular_name'                  => 'Услуга'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'services' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );
    register_post_type( 'services', $args );
}
add_action( 'init', 'coralina_custom_post_type_services' );

function coralina_custom_post_type_delivery() {
    $labels = array(
        'name'                  => 'Доставка'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'delivery' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
    );
    register_post_type( 'delivery', $args );
}
add_action( 'init', 'coralina_custom_post_type_delivery' );

function custom_taxonomy_for_coralina() {
    $location = array(
        'label'        => __( 'Расположение', 'textdomain' ),
        'public'       => true,
        'rewrite'      => false,
        'hierarchical' => true
    );

    register_taxonomy( 'location', 'delivery', $location );
}
add_action( 'init', 'custom_taxonomy_for_coralina', 0 );