<div class="grid-item sidebar"><?php get_sidebar(); ?></div>
<div class="grid-item contact">
	<?php echo get_breadcrumbs(); ?>
	<div class="grid-item delivery">
		<h1><?php the_title(); ?></h1>
		<?php the_post_thumbnail(); ?>
		<p><?php the_content(); ?></p>
	</div>
	<div class="grid-item maps">
		<?php
		if ( comments_open() || get_comments_number() ) :
			comments_template();
		endif;
		?>
	</div>
	<div class="grid-item feedback">
		<h1>Оставьте заявку на доставку бетона</h1>
		<?php echo do_shortcode('[contact-form-7 id="44" title="Контактная форма 1"]'); ?>
	</div>
</div>
<div class="grid-item license">
	<div class="grid-item testimonies">
		<img src="http://betonnyi-zavod.ru/template/img/svidetelstvo.svg">
		<p>Свидетельства и сертификаты качества</p>
	</div>
	<div class="grid-item supply">
		<img src="http://betonnyi-zavod.ru/template/img/dogovor.svg">
		<p>Договор поставки</p>
	</div>
	<div class="grid-item">
		<h1>Сеть бетонных заводов</h1>
		<h3>15 лет на рынке Москвы и МО</h3>
		<hr>
		<h2>+7 (499) 350-03-90</h2>
		<button class="order-click">КОНСУЛЬТАЦИЯ С МЕНЕДЖЕРОМ</button>
	</div>
</div>