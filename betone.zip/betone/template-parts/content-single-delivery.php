<div class="grid-item sidebar"><?php get_sidebar(); ?></div>
<div class="grid-item contact">
	<?php echo get_breadcrumbs(); ?>
	<div class="grid-item delivery">
		<h1><?php the_title(); ?> <mark><?php echo get_the_excerpt(); ?> руб.\м3</mark></h1>
		<?php the_post_thumbnail(); ?>
		<p><?php the_content(); ?></p>
	</div>
	<div class="grid-item maps">
		<center><h1>СЕГОДНЯ <mark><?php echo date ('d.m.Y'); ?></mark> вы получаете <mark>10% скидку</mark> на продукцию</h1></center>
		<table class="price-list">
			<thead><tr><th>Наименование</th> <th>Стоимость</th> <th>Количество кубов</th></tr></thead>
			<tbody>
				<?php
				$marks = new WP_Query(array('post_type' => 'marks', 'posts_per_page' => -1, 'order'   => 'ASC')); 
				if ($marks->have_posts()) :
					while ($marks->have_posts()) :
						$marks->the_post();
				?>
						<tr><td><?php the_title(); ?></td> <td><?php echo get_the_excerpt(); ?></td> <td nowrap="nowrap"><div class="in-box"><div id="<?php echo get_the_ID(); ?>" class="minusPlus minus" value="<?php echo get_the_excerpt(); ?>">-</div><input type="number" name="num" value="0" min="0" readonly="readonly" class="inputNumber" id="amount<?php echo get_the_ID(); ?>"><div id="<?php echo get_the_ID(); ?>" class="minusPlus plus" value="<?php echo get_the_excerpt(); ?>">+</div></div></td></tr>
				<?php
				endwhile;
				endif;
				wp_reset_query();
				?>
			</tbody>
		</table>
		<button class="cost-calculation order-click">ПОЛУЧИТЬ РАСЧЕТ СТОИОМСТИ</button>
	</div>
	<div class="grid-item feedback">
		<h1>Оставьте заявку на доставку бетона</h1>
		<?php echo do_shortcode('[contact-form-7 id="44" title="Контактная форма 1"]'); ?>
	</div>
</div>
<div class="grid-item license">
	<div class="grid-item testimonies">
		<img src="http://betonnyi-zavod.ru/template/img/svidetelstvo.svg">
		<p>Свидетельства и сертификаты качества</p>
	</div>
	<div class="grid-item supply">
		<img src="http://betonnyi-zavod.ru/template/img/dogovor.svg">
		<p>Договор поставки</p>
	</div>
	<div class="grid-item">
		<h1>Сеть бетонных заводов</h1>
		<h3>15 лет на рынке Москвы и МО</h3>
		<hr>
		<h2>+7 (499) 350-03-90</h2>
		<button class="order-click">КОНСУЛЬТАЦИЯ С МЕНЕДЖЕРОМ</button>
	</div>
</div>