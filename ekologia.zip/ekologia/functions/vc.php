<?php
if (class_exists("WPBakeryShortCode")) {
	class WPBakeryShortCode_Ekologia_Text extends WPBakeryShortCode {}
}
if (function_exists('vc_map')) {
	vc_map(array(
		'name' => esc_html__('Text', 'ekologia'),
		'base' => 'ekologia_text',
		'category' => esc_html__('Ekologia', 'ekologia'),
		'description' => esc_html__('Excerpt description', 'ekologua'),
		'show_settings_on_create' => true,
		'icon' => 'vc_general vc_element-icon icon-wpb-layout_sidebar',
		'weight' => -5,
		'params' => array(
			array(
				'type' => 'textfield',
				'heading' => esc_html__('Title', 'ekologia'),
				'param_name' => 'title',
				'value' => '',
				'description' => esc_html__('Description', 'ekologia')
			),
			array(
				'type' => 'colorpicker',
				'heading' => esc_html__('Color', 'ekologia'),
				'param_name' => 'color',
				'value' => '',
				'description' => esc_html__('Description', 'ekologia')
			)
		)
	));
}