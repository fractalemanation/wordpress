<?php
$args = array(
	'title' => '',
	'color' => ''
);
$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
?>

<h1 align="center" style="color: <?php echo $color; ?>;"><?php echo $title; ?></h1>