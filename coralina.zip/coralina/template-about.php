<?php
/**
 * Template name: About Template
 */

get_header();
?>

<?php
	while ( have_posts() ) :
		the_post();
?>
<section class="content about">
	<div class="container">
		<div class="tcw-wrap">
		<div class="content-title"><?php the_title(); ?></div>
		<?php echo get_breadcrumbs(); ?>
		</div>


	</div>
	</section>
	<section class="video">
	<div class="container">
		<div class="video-wrap">
			<a href="<?=get_post_meta($post->ID, 'ale_video', true)?>" class="prettyphoto" title="video" ><img src="<?=get_post_meta($post->ID, 'ale_image_first', true)?>" alt="" /></a>
		</div>
		<div class="vid-text">
			<h3><?php the_title(); ?></h3>
			<?php the_content(); ?>
		</div>
	</div>
 </section>
 <section class="partner">
	<div class="container">
		<div class="partner-h">
			<h3><?=get_post_meta($post->ID, 'ale_title_first', true)?></h3>
			<p><?=get_post_meta($post->ID, 'ale_description_first', true)?></p>
		</div>
		<div class="logos">
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_second', true)?>.png" alt="" /></a>
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_third', true)?>.png" alt="" /></a>
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_fourth', true)?>.png" alt="" /></a>
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_fifth', true)?>.png" alt="" /></a>
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_sixth', true)?>.png" alt="" /></a>
			<a href="#" ><img src="<?=get_template_directory_uri()?>/images/<?=get_post_meta($post->ID, 'ale_image_seventh', true)?>.png" alt="" /></a>
		</div>
	</div>
 </section>
 <section class="about-text">
	<div class="container">
		<div class="atw"><h3>Contrary to popular belief, Lorem Ipsum is not simply random text</h3></div>
		<div class="a-row">
		<div class="a-block">
			<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
		</div>
		<div class="a-block">
		<img src="<?=get_template_directory_uri()?>/images/a-img.jpg" alt="" class="rounded" />
		<script>
	$(function($) {
  var allAccordions = $('.accordion div.data');
  var allAccordionItems = $('.accordion .accordion-item');
  $('.accordion > .accordion-item').click(function() {
    if($(this).hasClass('open'))
    {
      $(this).removeClass('open');
      $(this).next().slideUp("slow");
    }
    else
    {
    allAccordions.slideUp("slow");
    allAccordionItems.removeClass('open');
    $(this).addClass('open');
    $(this).next().slideDown("slow");
    return false;
    }
  });
});
</script>
			<div class="accordion">
  <div class="accordion-item">
  <div class="type"></div>
    Lorem Ipsum passages, and more recently with desktop

  </div>
  <div class="data">
   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
  </div>
   <div class="accordion-item">
   <div class="type"></div>
                       There are many variations of passages of Lorem many
variations passages

           </div>
  <div class="data">
             when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.
  </div>
  <div class="accordion-item">
  <div class="type"></div>
                      Lorem Ipsum passages, and more recently with desktop

                                                                   </div>
  <div class="data">
             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
  </div>
  <div class="accordion-item">
  <div class="type"></div>
    Lorem Ipsum passages, and more recently with desktop

  </div>
  <div class="data">
   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
  </div>
</div>
		</div>
		</div>
	</div>
 </section>
 <div class="parallax"></div>
	<section class="facilities">
		<div class="container">
			<div class="f-block">
				<div class="f-air f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
			<div class="f-block">
				<div class="f-search f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
			<div class="f-block">
				<div class="f-glob f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
			<div class="f-block">
				<div class="f-loc f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
			<div class="f-block">
				<div class="f-bin f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
			<div class="f-block">
				<div class="f-photo f-sprite"></div>
				<div class="f-text">
					<p class="f-title">Lorem Ipsum </p>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
				</div>
			</div>
		</div>

	</section>
	<section class="bottom">
	<div class="container">
		<div class="bottom-nav">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu-1',
				'menu_id'        => 'primary-menu',
				'menu_class' => 'nav-menu',
				'container' => 'ul'
			) );
			?>
		</div>
		<div class="social">
			<?php
			if (!empty(get_post_meta($post->ID, 'ale_social_first', true))) :
			?>
				<a href="<?=get_post_meta($post->ID, 'ale_social_first', true)?>" target="_link" class="gp"><i class="fa fa-google-plus"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_second', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_second', true)?>" target="_link" class="tw"><i class="fa fa-twitter"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_third', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_third', true)?>" target="_link" class="fb"><i class="fa fa-facebook"></i></a>
			<?php
			endif;

			if (!empty(get_post_meta($post->ID, 'ale_social_fourth', true))) :
			?>
			<a href="<?=get_post_meta($post->ID, 'ale_social_fourth', true)?>" target="_link" class="ps"><i class="fa fa-pinterest"></i></a>
			<?php
			endif;
			?>
		</div>
	</div>
 </section>
 <?php endwhile; ?>

<?php get_footer();