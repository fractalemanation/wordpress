<?php
/**
* Template name: Contact Template
*/

get_header();
?>

<?php
	while ( have_posts() ) :
		the_post();
?>
<section class="content">
	<div class="container">
		<div class="tcw-wrap">
		<div class="content-title"><?php the_title(); ?></div>
		<div class="breadcrumb">
			<?=get_breadcrumbs()?>
		</div>
		</div>
		<div class="c-wrap">
			<div class="c-content">
				<?php the_content(); ?>
				<div class="c-contact">
					<?php if (get_post_meta($post->ID, 'ale_phone', true)): ?>
						<span class="c-icon"><i class="fa fa-phone"></i></span>
						<p>Phone:
							<span><strong><?=esc_attr(get_post_meta($post->ID, 'ale_phone', true))?></strong></span>
						</p>
					<?php endif; ?>
				</div>
				<div class="c-contact">
					<?php if (get_post_meta(get_the_ID(), 'ale_address', true)): ?>
						<span class="c-icon"><i class="fa fa-globe"></i></span>
						<p>Adress:
							<span><?=esc_attr(get_post_meta(get_the_ID(), 'ale_address', true))?></span>
						</p>
					<?php endif; ?>
				</div>
				<div class="c-contact">
					<?php if (get_post_meta($post->ID, 'ale_email', true)): ?>
						<span class="c-icon"><i class="fa fa-envelope-o"></i></span>
						<p>E-mail:
							<span><?=get_post_meta($post->ID, 'ale_email', true)?></span>
						</p>
					<?php endif; ?>
				</div>
			</div>
			<div class="c-form-w">
				<h3>Контактная форма</h3>
				<form>
					<?=do_shortcode(get_post_meta(get_the_ID(), 'ale_formcode', true))?>
				</form>
			</div>
		</div>
</section>
<?php endwhile; ?>

<?php get_footer(); ?>