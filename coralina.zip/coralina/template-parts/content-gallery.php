<div class="wrapper">
	<h2 class="post_title"><?php the_title(); ?></h2>
	<div class="excerpt"><?php the_excerpt(); ?></div>
	<div class="post_info">
		<div class="post_author"><?php echo the_author_posts_link(); ?></div>
		<div class="post_date"><?php the_date(); ?></div>
	</div>
	<?php the_post_thumbnail(); ?>
	<div class="post_content"><?php the_content(); ?></div>
	<?php comments_template(); ?>
</div>