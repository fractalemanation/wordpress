<?php get_header(); ?>

<center>
	<h2 class="page_title"><?php _e('Events', 'Aletheme'); ?></h2>
	<h3><?php single_term_title(); ?></h3>
	<div class="events_categories">
		<?php
		$wcatTerms = get_terms('events-category', array('hide_empty' => 0, 'parent' => 0));
		foreach ($wcatTerms as $wcatTerm) :
		?>
		<ul>
			<li>
				<a href="<?php echo get_term_link($wcatTerm->slug, $wcatTerm->taxonomy); ?>"><?php echo $wcatTerm->name; ?></a>
				<ul class="megaSubCat">
					<?php
					$wsubargs = array(
						'hierarchical' => 1,
						'show_option_none' => '',
						'hide_empty' => 0,
						'parent' => $wcatTerm->term_id,
						'taxonomy' => 'events-category'
					);
					$wsubcats = get_categories($wsubargs);
					foreach ($wsubcats as $wsc):
					?>
					<li><a href="<?php echo get_term_link($wsc->slug, $wsc->taxonomy);?>"><?php echo $wsc->name; ?></a></li>
					<?php
					endforeach;
					?>
				</ul>
			</li>
		</ul>
		<?php
		endforeach;
		?>
	</div>
	<div class="events_list">
		<?php
		if (have_posts()):
			while (have_posts()):
				the_post();
		?>
		<article class="item_event">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			<div><?php echo get_the_date(); ?></div>
		</article>
		<?php
			endwhile;
		endif;
		?>
	</div>
	<?php the_posts_pagination(); ?>
</center>

<?php get_footer(); ?>