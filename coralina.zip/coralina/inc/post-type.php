<?php
function coralina_custom_post_type_gallery() {
    $labels = array(
        'name'                  => 'Галерея'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'gallery' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );
    register_post_type( 'gallery', $args );
}
add_action( 'init', 'coralina_custom_post_type_gallery' );

function coralina_custom_post_type_deals() {
    $labels = array(
        'name'                  => 'Сделки',
        'singular_name'         => 'Сделка'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'deals' ),//ссылка
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );
    register_post_type( 'deals', $args );
}
add_action( 'init', 'coralina_custom_post_type_deals' );

function coralina_custom_post_type_testimonials() {
    $labels = array(
        'name'                  => 'Отзывы',
        'singular_name'                  => 'Отзыв'
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'testimonials' ),//ссылка
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'thumbnail' ),
    );
    register_post_type( 'testimonials', $args );
}
add_action( 'init', 'coralina_custom_post_type_testimonials' );

function custom_taxonomy_for_coralina() {
    $args = array(
        'label'        => __( 'Местоположение', 'textdomain' ),
        'public'       => true,
        'rewrite'      => false,
        'hierarchical' => true
    );
    $args_price = array(
        'label'        => __( 'Цена', 'textdomain' ),
        'public'       => true,
        'rewrite'      => false,
        'hierarchical' => true
    );
    $args_type = array(
        'label'        => __( 'Тип', 'textdomain' ),
        'public'       => true,
        'rewrite'      => false,
        'hierarchical' => true
    );

    register_taxonomy( 'location', 'deals', $args );
    register_taxonomy( 'price', 'deals', $args_price );
    register_taxonomy( 'type', 'deals', $args_type );//id, name, settings
}
add_action( 'init', 'custom_taxonomy_for_coralina', 0 );