<?php
function filter_deals_post($data){

	$args = array(
		'posts_per_page' => '5',
		'tax_query' => array(
			'relation' => 'AND'//OR
		)
	);

	if(isset($data['location']) && isset($data['location']) !== '') {
		array_push($args['tax_query'], array(
			'taxonomy'=>'location',
			'field'    => 'name',//'term_id'
			'terms' => array($data['location'])
		));
	}

	if(isset($data['type']) && isset($data['type']) !== '') {
		array_push($args['tax_query'], array(
			'taxonomy'=>'type',
			'field'    => 'name',
			'terms' => array($data['type'])
		));
	}
	if(isset($data['price']) && isset($data['price']) !== '') {
		array_push($args['tax_query'], array(
			'taxonomy'=>'price',
			'field'    => 'name',
			'terms' => array($data['price'])
		));
	}

/*$args = array(
	'posts_per_page' => 'properties',
	'post_type' => array('relation' => 'AND'),
	'meta_query' => array('relation' => 'AND')//Для metabox
);
if (isset($data['sale']) && $data['sale'] != '') {
	array_push($args['meta_query'], array(
		'key' => 'colarina_propertycontract',
		'value' => array($data['sale'])
	));//Для metabox
}*/
	$custom_filter = new WP_Query($args);
	if(!empty($_POST)){
		/* Это вывод результата поиска */
		if ( $custom_filter->have_posts() ) :
			?>
			<div class="container">
				<div class="hot-d">
					<div class="hd-b">
			<?php
			while ( $custom_filter->have_posts() ) :
				$custom_filter->the_post();
?>
						<div class="hd-block">
							<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
							<div class="hd-block-text">
								<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
								<?php the_content(); ?>
								<div class="block-text-bottom">
									<span class="price"><?=substr($data['price'], 0, -7)?></span>
									<span><img src="<?php echo get_template_directory_uri(); ?>/images/bus.png" alt="" /></span>
									<span class="date"><?=$data['location']?></span>
								</div>
							</div>
						</div>
<?php
			endwhile;
		else : echo "<br><br><br><center><h1>Ничего не найдено</h1></center><br><br><br>";
		endif;
?>
				</div>
			</div>
		</div>
<?php
	} else {
?>
<section class="hotdeals">
		<div class="container">
<?php
		$default_query = new WP_Query(array('post_type'=>'deals','posts_per_page'=>10));
		if ( $default_query->have_posts() ) :
			while ( $default_query->have_posts() ) :
				$default_query->the_post();
?>
					<div class="hd-block">
						<img src="<?=get_the_post_thumbnail_url()?>" alt="" />
						<div class="hd-block-text">
							<?php the_title( sprintf( '<a href="%s"><h3>', esc_url( get_permalink() ) ), '</h3></a>' ); ?>
							<?php the_excerpt(); ?>
							<?php the_content(); ?>
							<?php echo get_the_date(); ?>
							<?php //the_permalink(); ?>
						</div>
					</div>
<?php
			endwhile;
?>
	</div>
</section>
<?php
		else : echo "Ничего не найдено";
		endif;
	}

}