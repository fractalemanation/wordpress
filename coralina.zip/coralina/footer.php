<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package coralina
 */

global $coralina_option;
$logo_footer = $coralina_option['coralina-logo-footer']['url'];
$description_footer = $coralina_option['coralina-description-footer'];
$date_footer = $coralina_option['coralina-date-footer'];
$menu_first_footer = $coralina_option['coralina-menu-first-footer'];
$menu_second_footer = $coralina_option['coralina-menu-second-footer'];
$menu_third_footer = $coralina_option['coralina-menu-third-footer'];
$global_footer = $coralina_option['coralina-globe-footer'];
$phone_footer = $coralina_option['coralina-phone-footer'];
$email_footer = $coralina_option['coralina-envelope-footer'];
?>

<footer>
	<div class="container">
		<div class="column-f">
			<img src="<?=esc_url($logo_footer)?>" alt="" />
			<p><?=esc_attr($description_footer)?></p>
			<p><?=esc_attr($date_footer)?></p>
		</div>
		<div class="column-s">
			<h3><?=esc_attr($menu_first_footer)?></h3>
			<ul>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer-support',
					'menu_id'        => 'footer-support-id',
					'menu_class' => '',
					'container' => 'ul'
				) );
				?>
			</ul>
		</div>
		<div class="column-t">
			<h3><?=esc_attr($menu_second_footer)?></h3>
			<ul>
				<?php
				wp_nav_menu( array(
					'theme_location' => 'footer-information',
					'menu_id'        => 'footer-information-id',
					'menu_class' => '',
					'container' => 'ul'
				) );
				?>
			</ul>
		</div>
		<div class="column-l">
			<h3><?=esc_attr($menu_third_footer)?></h3>
			<ul>
				<li><a href="#"><i class="fa fa-globe"></i><?=esc_attr($global_footer)?> 
</a></li>
			<li><a href="#"><i class="fa fa-phone"></i><?=esc_attr($phone_footer)?></a></li>
			<li><a href="#"><i class="fa fa-envelope-o"></i><?=esc_attr($email_footer)?></a></li>
			
			</ul>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>

</body>
</html>